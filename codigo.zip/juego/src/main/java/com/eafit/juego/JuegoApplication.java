package com.eafit.juego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuegoApplication.class, args);
	}

}
